HCFCD MODEL SUMMARY METADATA
The purpose of this summary is to document the high points of hydrologic and hydraulic models filed within the HCFCD Model and Map Management (M3) system.  The document includes references to the project that prompted the creation or update of the model.

DESCRIPTION OF PROJECT:  
The following model was the hydraulic model which represented the effective condition of Harris County's watersheds.
 
PURPOSE OF PROJECT:
Development of effective models to support the National Flood Insurance Program.

HCFCD Watershed Unit ID: D 
M3 Study Identifier: 2007_Effective_D
Engineer: HCFCD   
Project Name: EffectiveFEMA Study for watershed Brays Bayou (D)
Study Completion Date: 6/18/2007
FEMA Case Number: [No Data]
FEMA Approval Date: [No Date in Database]
Vertical Datum: NAVD 1988
Datum Note: 2001 ADJ

HYDRAULICS
HCFCD Unit No.:  D112-00-00 
Hydraulic Program Name: HEC-RAS
Hydraulic Program Version: 3.0.1 
Steady Hydraulic Model: Yes
Unsteady Hydraulic Model: No



