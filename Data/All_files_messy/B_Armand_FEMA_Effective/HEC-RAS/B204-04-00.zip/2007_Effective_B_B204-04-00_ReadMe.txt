HCFCD MODEL SUMMARY METADATA
The purpose of this summary is to document the high points of hydrologic and hydraulic models filed within the HCFCD Model and Map Management (M3) system.  The document includes references to the project that prompted the creation or update of the model.

DESCRIPTION OF PROJECT:  
[Description]
 
PURPOSE OF PROJECT:
[Proj_Purpose]

HCFCD Watershed Unit ID: [PrimaryWshd] 
M3 Study Identifier: 2007_Effective_B
Engineer: [Model_Developer]   
Project Name: [RequestName]
Study Completion Date: [EffectiveDate]
FEMA Case Number: [LOMC_CASE]
FEMA Approval Date: [RequestApprovalDate]
Vertical Datum: [Datum]
Datum Note: [Datum_Note]

HYDRAULICS
HCFCD Unit No.:  [ModelUnit] 
Hydraulic Program Name: [SoftwareName]
Hydraulic Program Version: [ModelVersion] 
Steady Hydraulic Model: [HydSteady]
Unsteady Hydraulic Model: [HydUnsteady]



