HCFCD MODEL SUMMARY METADATA
The purpose of this summary is to document the high points of hydrologic and hydraulic models filed within the HCFCD Model and Map Management (M3) system.  The document includes references to the project that prompted the creation or update of the model.

DESCRIPTION OF PROJECT:  
The following model was the hydraulic model which represented the effective condition of Harris County's watersheds.
 
PURPOSE OF PROJECT:
Development of effective models to support the National Flood Insurance Program. 

HCFCD Watershed Unit ID: Q 
M3 Study Identifier: Q114-00-00 Pending Effective Model 
Engineer:  
Study Completion Date: 11/08/2016 
FEMA Case Number:   
FEMA Approval Date: 06/18/2007 
Vertical Datum: NAVD 1988 
Datum Note: 2001 ADJ 

HYDRAULICS
HCFCD Unit No.:  Q114-00-00
Hydraulic Program Name: HEC-RAS
Hydraulic Program Version: 3.0.1
Steady Hydraulic Model: Yes
Unsteady Hydraulic Model: No


Update1:
FEMA Case Number: 18-06-2955P
FEMA Effective Date: 01/22/2019
Description: Update2: The effective FEMA hydraulic model for unit number Q114-00-00 has been updated by FEMA LOMR 18-06-2955P with an effective date of 01/22/2019.
