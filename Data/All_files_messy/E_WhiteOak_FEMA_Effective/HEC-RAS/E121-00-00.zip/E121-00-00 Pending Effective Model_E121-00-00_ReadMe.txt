HCFCD MODEL SUMMARY METADATA
The purpose of this summary is to document the high points of hydrologic and hydraulic models filed within the HCFCD Model and Map Management (M3) system.  The document includes references to the project that prompted the creation or update of the model.

DESCRIPTION OF PROJECT:  
The effective FEMA hydraulic model for unit number E121-00-00 has been updated by FEMA LOMR 16-06-0527P with an effective date of 11/04/2016.
 
PURPOSE OF PROJECT:
The effective FEMA hydraulic model for unit number E121-00-00 has been updated by FEMA LOMR 16-06-0527P with an effective date of 11/04/2016. 

HCFCD Watershed Unit ID: E 
M3 Study Identifier: E121-00-00 Pending Effective Model 
Engineer:  
Study Completion Date: 11/08/2016 
FEMA Case Number: 16-06-0527P 
FEMA Approval Date: 11/04/2016 
Vertical Datum: NAVD 1988 
Datum Note: 2001 ADJ 

HYDRAULICS
HCFCD Unit No.:  E121-00-00
Hydraulic Program Name: HEC-RAS
Hydraulic Program Version: 4.0
Steady Hydraulic Model: Yes
Unsteady Hydraulic Model: No


Update:
N.A.
