HCFCD MODEL SUMMARY METADATA
The purpose of this summary is to document the high points of hydrologic and hydraulic models filed within the HCFCD Model and Map Management (M3) system.  The document includes references to the project that prompted the creation or update of the model.

DESCRIPTION OF PROJECT:  
The following model was the hydrologic model which represented the effective condition of Harris County’s watersheds.
 
PURPOSE OF PROJECT:
The purpose of this summary is to document the high points of hydrologic and hydraulic models filed within the HCFCD Model and Map Management (M3) system.  The document includes references to the project that prompted the creation or update of the model. 

HCFCD Watershed Unit ID: E 
M3 Study Identifier: E100-00-00 Pending Effective Model 
Engineer:  
Study Completion Date: 06/11/2014 
FEMA Case Number: 10-06-0969P 
FEMA Approval Date: 06/09/2014 
Vertical Datum: NAVD 1988 
Datum Note: 2001 ADJ 

HYDRAULICS
HCFCD Unit No.:  E100-00-00
Hydraulic Program Name: HEC-RAS
Hydraulic Program Version: 4.0
Steady Hydraulic Model: Yes
Unsteady Hydraulic Model: No


Update:
N.A.
