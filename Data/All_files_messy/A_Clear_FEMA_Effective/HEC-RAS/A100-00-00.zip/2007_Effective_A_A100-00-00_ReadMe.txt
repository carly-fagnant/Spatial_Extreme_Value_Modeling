HCFCD MODEL SUMMARY METADATA
The purpose of this summary is to document the high points of hydrologic and hydraulic models filed within the HCFCD Model and Map Management (M3) system.  The document includes references to the project that prompted the creation or update of the model.

DESCRIPTION OF PROJECT:  
The following model was the hydraulic model which represented the effective condition of Harris County�s watersheds.
 
PURPOSE OF PROJECT:
Development of effective models to support the National Flood Insurance Program.

HCFCD Watershed Unit ID: A 
M3 Study Identifier: 2007_Effective_A
Engineer: HCFCD   
Project Name: EffectiveFEMA Study for watershed Clear Creek (A)
Study Completion Date: 6/18/2007
FEMA Case Number: [No Data]
FEMA Approval Date: [No Date in Database]
Vertical Datum: NAVD 1988
Datum Note: 2001 ADJ

HYDRAULICS
HCFCD Unit No.:  A100-00-00 
Hydraulic Program Name: HEC-RAS
Hydraulic Program Version: 3.0.1 
Steady Hydraulic Model: Yes
Unsteady Hydraulic Model: No



Update1:
The effective FEMA hydraulic model for unit number A100-00-00 has been updated by FEMA LOMR 09-06-1180P with an effective date of 5/28/2009.

Update2:
The effective FEMA hydraulic model for unit number A100-00-00 has been updated by FEMA LOMR 08-06-0819P with an effective date of 10/29/2009.

Update3:
The effective FEMA hydraulic model for unit number A100-00-00 has been updated by FEMA LOMR 12-06-1209P with an effective date of 11/08/2012.

Update4:
The effective FEMA hydraulic model for unit number A100-00-00 has been updated by FEMA LOMR 13-06-1986P with an effective date of 11/14/2013.

Update5:
The effective FEMA hydraulic model for unit number A100-00-00 has been updated by FEMA LOMR 13-06-1908P with an effective date of 2/6/2014.

Update6:
The effective FEMA hydraulic model for unit number A100-00-00 has been updated by FEMA LOMR 13-06-1076P with an effective date of 3/6/2014.

Update7:
The effective FEMA hydraulic model for unit number A100-00-00 has been updated by FEMA LOMR 14-06-3038P with an effective date of 12/26/2014.

Update8:
This update includes a LOMR that the previous update did not include.  The model for unit number A100-00-00 has an effective date of 12/26/2014.

Update9:
The effective FEMA hydraulic model for unit number A100-00-00 has been updated by FEMA LOMR 19-06-2864P with an effective date of XX/XX/2020.

Update10:
The effective FEMA hydraulic model for unit number A100-00-00 has been updated by FEMA LOMR 21-06-0613P with an effective date of 12/28/2021.