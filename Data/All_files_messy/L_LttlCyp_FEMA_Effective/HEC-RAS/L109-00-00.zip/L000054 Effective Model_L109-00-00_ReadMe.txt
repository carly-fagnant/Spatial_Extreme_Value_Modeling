HCFCD MODEL SUMMARY METADATA
The purpose of this summary is to document the high points of hydrologic and hydraulic models filed within the HCFCD Model and Map Management (M3) system.  The document includes references to the project that prompted the creation or update of the model.

DESCRIPTION OF PROJECT:  
The following model was the hydraulic model which represented the effective condition of Harris County's watersheds.
 
PURPOSE OF PROJECT:
Development of effective models to support the National Flood Insurance Program.

HCFCD Watershed Unit ID: L 
M3 Study Identifier: 2007_Effective_L
Engineer: HCFCD   
Project Name: EffectiveFEMA Study for watershed Little Cypress Creek (L)
Study Completion Date: 6/18/2007
FEMA Case Number: [No Data]
FEMA Approval Date: [No Date in Database]
Vertical Datum: NAVD 1988
Datum Note: 2001 ADJ

HYDRAULICS
HCFCD Unit No.:  L109-00-00 
Hydraulic Program Name: HEC-RAS
Hydraulic Program Version: 3.0.1 
Steady Hydraulic Model: Yes
Unsteady Hydraulic Model: No





Update1:
FEMA Case Number: 13-06-4126P
FEMA Effective Date: 04/09/2015
Description: Update1: The effective FEMA hydraulic model for unit number L109-00-00 has been updated by FEMA LOMR 13-06-4126P with an effective date of 4/09/2015.
