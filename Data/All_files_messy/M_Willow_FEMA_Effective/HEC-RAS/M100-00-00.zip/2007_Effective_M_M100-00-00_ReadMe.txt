HCFCD MODEL SUMMARY METADATA
The purpose of this summary is to document the high points of hydrologic and hydraulic models filed within the HCFCD Model and Map Management (M3) system.  The document includes references to the project that prompted the creation or update of the model.

DESCRIPTION OF PROJECT:  
The following model was the hydraulic model which represented the effective condition of Harris County�s watersheds.
 
PURPOSE OF PROJECT:
Development of effective models to support the National Flood Insurance Program.

HCFCD Watershed Unit ID: M 
M3 Study Identifier: 2007_Effective_M
Engineer: HCFCD   
Project Name: EffectiveFEMA Study for watershed Willow Creek (M)
Study Completion Date: 6/18/2007
FEMA Case Number: [No Data]
FEMA Approval Date: [No Date in Database]
Vertical Datum: NAVD 1988
Datum Note: 2001 ADJ

HYDRAULICS
HCFCD Unit No.:  M100-00-00 
Hydraulic Program Name: HEC-RAS
Hydraulic Program Version: 3.0.1 
Steady Hydraulic Model: Yes
Unsteady Hydraulic Model: No

Update1:
The effective FEMA hydraulic model for unit number M100-00-00 has been updated by FEMA LOMR 07-06-1888P with an effective date of 7/25/2007.

Update2:
The effective FEMA hydraulic model for unit number M100-00-00 has been updated by FEMA LOMR 07-06-2077P with an effective date of 10/30/2008.

Update3:
The effective FEMA hydraulic model for unit number M100-00-00 has been updated by FEMA LOMR 12-06-2603P with an effective date of 1/28/2013.

Update4:
The effective FEMA hydraulic model for unit number M100-00-00 has been updated by FEMA LOMR 15-06-0175P with an effective date of 8/26/2015.

Update5:
The effective FEMA hydraulic model for unit number M100-00-00 has been pulled back to FEMA LOMR 12-06-2603P with an effective date of 1/28/2013.
The GIS cross sections have been updated to reflect the new regulatory water surface elevations from 15-06-0175P with an effective date of 8/26/2015.

Update6:
The effective FEMA hydraulic model for unit number M100-00-00 has been updated by FEMA LOMR 15-06-0921P with an effective date of 6/29/2016.

Update 7:
The effective FEMA hydraulic model for unit number M100-00-00 has been updated by FEMA LOMR 16-06-4206P with an effective date of 9/18/2017.

Update 8:
The effective FEMA hydraulic model for unit number M100-00-00 has been updated by FEMA LOMR 16-06-3930P with an effective date of 9/25/2017.
