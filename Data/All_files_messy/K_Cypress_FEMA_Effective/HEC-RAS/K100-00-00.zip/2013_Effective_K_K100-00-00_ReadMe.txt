HCFCD MODEL SUMMARY METADATA
The purpose of this summary is to document the high points of hydrologic and hydraulic models filed within the HCFCD Model and Map Management (M3) system.  The document includes references to the project that prompted the creation or update of the model.

DESCRIPTION OF PROJECT:  
The following model was the hydraulic model which represented the effective condition of Harris County�s watersheds.
 
PURPOSE OF PROJECT:
Development of effective models to support the National Flood Insurance Program.

HCFCD Watershed Unit ID: K 
M3 Study Identifier: 2013_Effective_K
Engineer: HCFCD   
Project Name: Effective FEMA Study for watershed Cypress Creek (K)
Study Completion Date: X/XX/2013
FEMA Case Number: 08-06-2369P
FEMA Approval Date: 10/16/2013
Vertical Datum: NAVD 1988
Datum Note: 2001 ADJ

HYDRAULICS
HCFCD Unit No.:  K100-00-00 
Hydraulic Program Name: HEC-RAS
Hydraulic Program Version: 3.1.3 
Steady Hydraulic Model: Yes
Unsteady Hydraulic Model: No


Update 1:
The effective FEMA hydraulic model for unit number K100-00-00 has been updated by FEMA LOMR 12-06-3910P with an effective date of 2/6/2014.
	
Update 2:
The effective FEMA hydraulic model for unit number K100-00-00 has been updated by FEMA LOMR 14-06-2578P with an effective date of 7/13/2015.

Update 3:
The effective FEMA hydraulic model for unit number K100-00-00 has been updated by FEMA LOMR 17-06-4282P with an effective date of 4/30/2018.

Update 4:
The effective FEMA hydraulic model for unit number K100-00-00 has been updated by FEMA LOMR 18-06-0276P with an effective date of 6/18/2018.

Update 5:
The effective FEMA hydraulic model for unit number K100-00-00 has been updated by FEMA LOMR 18-06-3326P with an effective date of 11/18/2019.