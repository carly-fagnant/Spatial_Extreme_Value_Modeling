HCFCD MODEL SUMMARY METADATA
The purpose of this summary is to document the high points of hydrologic and hydraulic models filed within the HCFCD Model and Map Management (M3) system.  The document includes references to the project that prompted the creation or update of the model.

DESCRIPTION OF PROJECT:  
The following model was the hydraulic model which represented the effective condition of Harris County's watersheds.
 
PURPOSE OF PROJECT:
Development of effective models to support the National Flood Insurance Program.

HCFCD Watershed Unit ID: K 
M3 Study Identifier: 2007_Effective_K
Engineer: HCFCD   
Project Name: EffectiveFEMA Study for watershed Cypress Creek (K)
Study Completion Date: 6/18/2007
FEMA Case Number: [No Data]
FEMA Approval Date: [No Date in Database]
Vertical Datum: NAVD 1988
Datum Note: 2001 ADJ

HYDRAULICS
HCFCD Unit No.:  K145-00-00 
Hydraulic Program Name: HEC-RAS
Hydraulic Program Version: 3.0.1 
Steady Hydraulic Model: Yes
Unsteady Hydraulic Model: No

Update1:
The effective FEMA hydraulic model for unit number K145-00-00 has been updated by FEMA LOMR 10-06-0650P with an effective date of 5/27/2010.

Update2:
The effective FEMA hydraulic model for unit number K145-00-00 has been updated by FEMA LOMR 10-06-2260P with an effective date of 1/7/2011.



Update3:
FEMA Case Number: 15-06-3864P
FEMA Effective Date: 11/18/2016
Description: Update3: The effective FEMA hydraulic model for unit number K145-00-00 has been updated by FEMA LOMR 15-06-3864P with an effective date of 11/18/2016.
