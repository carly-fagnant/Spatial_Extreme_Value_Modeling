HCFCD MODEL SUMMARY METADATA
The purpose of this summary is to document the high points of hydrologic and hydraulic models filed within the HCFCD Model and Map Management (M3) system.  The document includes references to the project that prompted the creation or update of the model.

DESCRIPTION OF PROJECT:  
The following model was the hydraulic model which represented the effective condition of Harris County’s watersheds.
 
PURPOSE OF PROJECT:
Development of effective models to support the National Flood Insurance Program. 

HCFCD Watershed Unit ID: K 
M3 Study Identifier: K172-00-00 Pending Effective Model 
Engineer:  
Study Completion Date: 05/12/2014 
FEMA Case Number: 08-06-2369P 
FEMA Approval Date: 10/16/2013 
Vertical Datum: NAVD 1988 
Datum Note: 2001 ADJ 

HYDRAULICS
HCFCD Unit No.:  K172-00-00
Hydraulic Program Name: HEC-RAS
Hydraulic Program Version: 3.1.3
Steady Hydraulic Model: Yes
Unsteady Hydraulic Model: No


Update:
N.A.
